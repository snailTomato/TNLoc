import tensorflow as tf
import numpy as np
import os
import h5py
import time
import properties
import sys

_SAMPLE_SIZE = properties.parse_arguments(sys.argv[1:]).sample_size


def load_train_data(file_name):
    """Load fingerprint map.

    Args:
      file_name: str
    Returns:
      train_rssi: rssi matrix[RP,AP] for fingerprint map.
      train_label: lable matrix[RP,2] for fingerprint map, lable is laction (x,y).
    """
    if os.path.exists(file_name):
        with h5py.File(file_name, 'r') as f:
            train_rssi= f['data'][:].astype(np.float32)
            train_label = f['label'][:]
            train_rssi = train_rssi + 100
        return train_rssi, train_label
    else:
        print("file no exit")


def triplet_loss(query, positive, negative, alpha):
    """Loss function.

    The loss function for CNN.

       Returns:
         loss.
    """
    with tf.variable_scope('triplet_loss'):
        pos_dist = tf.reduce_sum(tf.square(tf.subtract(query, positive)), 1)
        neg_dist = tf.reduce_sum(tf.square(tf.subtract(query, negative)), 1)
        basic_loss = tf.add(tf.subtract(pos_dist, neg_dist), alpha)
        loss = tf.reduce_mean(tf.maximum(basic_loss, 0.0), 0)
    return loss


def select_custom_triplets(sample_mul_all, ppc, alpha):
    """ Select my custiom triplets.

    Select triplets for training.

        Args:
          sample_mul_all: rssi pidst matrix.
          ppc : positive point candidate.
          alpha.
        Returns:
          triplets: contain anchor, positive , negative points.
    """
    max_trips = 0
    triplets = []

    for i, one in enumerate(ppc):
        for j in one:
            for a in np.arange(i*_SAMPLE_SIZE,(i+1)*_SAMPLE_SIZE):
                for p in np.arange(j*_SAMPLE_SIZE,(j+1)*_SAMPLE_SIZE):
                    positive_dist = sample_mul_all[a,p]
                    sample_mul_all[a,p] = np.inf
                    n_candi = np.where(sample_mul_all[a,:] - positive_dist < alpha)[0]
                    if len(n_candi)>0:
                        n = np.random.choice(n_candi)
                        triplets.append([a, p, n])
                    max_trips += 1

    np.random.shuffle(triplets)
    return triplets, max_trips


def graph_train(total_loss, global_step, optimizer, learning_rate, moving_average_decay, update_gradient_vars, log_histograms=True):
    """Train the graph of tensorflow.

    Trains the model with one batch of examples and updates the model parameters for the graph of tensorflow.

       Returns:
         train_op: operation of graph training.
    """
    # Generate moving averages of all losses and associated summaries.
    loss_averages_op = _add_loss_summaries(total_loss)

    opt = 0
    grads = 0
    # Compute gradients.
    with tf.control_dependencies([loss_averages_op]):
        if optimizer == 'ADAGRAD':
            opt = tf.train.AdagradOptimizer(learning_rate)
        elif optimizer == 'ADADELTA':
            opt = tf.train.AdadeltaOptimizer(learning_rate, rho=0.9, epsilon=1e-6)
        elif optimizer == 'ADAM':
            opt = tf.train.AdamOptimizer(learning_rate, beta1=0.9, beta2=0.999, epsilon=0.1)
        elif optimizer == 'RMSPROP':
            opt = tf.train.RMSPropOptimizer(learning_rate, decay=0.9, momentum=0.9, epsilon=1.0)
        elif optimizer == 'MOM':
            opt = tf.train.MomentumOptimizer(learning_rate, 0.9, use_nesterov=True)
        else:
            raise ValueError('Invalid optimization algorithm')

        grads = opt.compute_gradients(total_loss, update_gradient_vars)

    # Apply gradients.
    apply_gradient_op = opt.apply_gradients(grads, global_step=global_step)

    # Add histograms for trainable variables.
    if log_histograms:
        for var in tf.trainable_variables():
            tf.summary.histogram(var.op.name, var)

    # Add histograms for gradients.
    if log_histograms:
        for grad, var in grads:
            if grad is not None:
                tf.summary.histogram(var.op.name + '/gradients', grad)

    # Track the moving averages of all trainable variables.
    variable_averages = tf.train.ExponentialMovingAverage(
        moving_average_decay, global_step)
    variables_averages_op = variable_averages.apply(tf.trainable_variables())

    with tf.control_dependencies([apply_gradient_op, variables_averages_op]):
        train_op = tf.no_op(name='train')

    return train_op


def train(args, sess, epoch, train_data, same_location, pn_in_posicandi, train_phase_placeholder,
          rss_placeholder, sl_placeholder, learning_rate_placeholder, global_step, embeddings, loss,
          train_op, summary_writer, embedding_size, matrix_a_placeholder, matrix_b_placeholder, pdist, learning_rate):
    """Train the model.

    Train the model for one epoch.

    """
    batch_number = 0
    step = 0
    lr = args.learning_rate

    nof_vectors = train_data.shape[0]
    emb_array = np.zeros((nof_vectors, embedding_size))
    nrof_batches = int(np.ceil(nof_vectors / args.batch_size))
    for i in range(nrof_batches):
        batch_size = min(nof_vectors - i * args.batch_size, args.batch_size)
        indices = np.arange(i * args.batch_size, i * args.batch_size + batch_size)
        feed_dict = {rss_placeholder: train_data[indices], train_phase_placeholder: False}
        emb = sess.run(embeddings, feed_dict=feed_dict)
        emb_array[indices] = emb

    start_time = time.time()
    print('Selecting suitable triplets for training')
    all_mul_all = sess.run(pdist, feed_dict={matrix_a_placeholder: emb_array, matrix_b_placeholder: emb_array})
    self_axis = np.arange(nof_vectors)
    all_mul_all[self_axis, self_axis] = 0
    triplets, max_neg = select_custom_triplets(all_mul_all, pn_in_posicandi, args.alpha)
    selection_time = time.time() - start_time
    print('time=%.3f seconds\n(tripletdf/max_negdf) = (%d, %d)' %
          (selection_time, len(triplets), max_neg))

    if len(triplets) == 0:
        raise Exception('All data satisfy triplet constraint')
    triplets = np.row_stack(triplets)
    np.random.shuffle(triplets)
    nrof_examples = triplets.shape[0]
    nrof_batches = int(np.ceil(nrof_examples / args.batch_size))
    train_time = 0
    i = 0
    while i < nrof_batches:
        start_time = time.time()
        batch_size = min(nrof_examples - i * args.batch_size, args.batch_size)
        indices_of_batch = np.arange(i * args.batch_size, i * args.batch_size + batch_size)
        mini_triplet_idx = triplets[indices_of_batch]
        sl = same_location[mini_triplet_idx[:, 0], mini_triplet_idx[:, 1]]
        indices = np.hstack(mini_triplet_idx)
        feed_dict = {rss_placeholder: train_data[indices], train_phase_placeholder: True, learning_rate_placeholder: lr, sl_placeholder: sl}
        err, _, step, rate = sess.run([loss, train_op, global_step, learning_rate], feed_dict=feed_dict)
        duration = time.time() - start_time
        print('Epoch: [%d][%d/%d]\tTime %.3f\tLoss %2.3f\tLearning rate %.5f'
              % (epoch, batch_number, nrof_batches, duration, err, rate))
        batch_number += 1
        i += 1
        train_time += duration

    # Add validation loss and accuracy to summary
    summary = tf.Summary()
    summary.value.add(tag='time/selection', simple_value=selection_time)
    summary_writer.add_summary(summary, step)


def _add_loss_summaries(total_loss):
    """Add summaries for losses.

    Generates moving average for all losses and associated summaries for
    visualizing the performance of the network.

    Args:
      total_loss: Total loss from loss().
    Returns:
      loss_averages_op: op for generating moving averages of losses.
    """
    # Compute the moving average of all individual losses and the total loss.
    loss_averages = tf.train.ExponentialMovingAverage(0.9, name='avg')
    losses = tf.get_collection('losses')
    loss_averages_op = loss_averages.apply(losses + [total_loss])

    # Attach a scalar summary to all individual losses and the total loss; do the
    # same for the averaged version of the losses.
    for l in losses + [total_loss]:
        # Name each loss as '(raw)' and name the moving average version of the loss
        # as the original loss name.
        tf.summary.scalar(l.op.name + ' (raw)', l)
        tf.summary.scalar(l.op.name, loss_averages.average(l))

    return loss_averages_op


def sample_data(label, data, rate):
    """Sample from data.

    Divide the train data into two part, tate of data as train data and (1-rate) of data as test data for the later evaluation stage.

    Args:
      rate < 1.
    Returns:
      refer: train data
      infer: test data
    """
    bf_class = []
    points_group = []
    for i, one in enumerate(label[:, 0]):
        try:
            idx = bf_class.index(one)
        except ValueError:
            bf_class.append(one)
            points_group.append([])
            points_group[-1].append(i)
        else:
            points_group[idx].append(i)
    ri_rate = rate
    r_inds = []
    i_inds = []
    for one in points_group:
        np.random.shuffle(one)
        line = np.ceil(len(one) * ri_rate).astype(np.int32)
        r_inds.append(one[:line])
        i_inds.append(one[line:])
    r_inds, i_inds = np.hstack(r_inds).astype(np.int32), np.hstack(i_inds).astype(np.int32)
    refer_data, infer_data = data[r_inds], data[i_inds]
    refer_label, infer_label = label[r_inds], label[i_inds]
    return refer_data, refer_label, infer_data, infer_label


def evaluate(sess, rss_placeholder, embeddings, pdist, matrix_a_placeholder, matrix_b_placeholder, step, epoch, train_phase_placeholder,
             refer_data, refer_label, infer_data, infer_label, log_dir, summary_writer, k, embedding_size, batch_size):
    """Evaluate the model.

    Compare the performance of model and WKNN.


    Returns:
      mean: mean position error.
    """
    # Run forward pass to calculate embeddings
    all_rss_num = refer_data.shape[0] + infer_data.shape[0]
    all_data = np.row_stack((refer_data, infer_data))
    emb_array = np.zeros((all_rss_num, embedding_size))
    nrof_batches = int(np.ceil(all_rss_num / batch_size))
    for i in range(nrof_batches):
        iterator = min(all_rss_num - i * batch_size, batch_size)
        indices = np.arange(i * batch_size, i * batch_size + iterator)
        feed_dict = {rss_placeholder: all_data[indices], train_phase_placeholder: False}
        emb = sess.run(embeddings, feed_dict=feed_dict)
        emb_array[indices] = emb
    emb_refer, emb_infer = emb_array[:refer_data.shape[0]], emb_array[refer_data.shape[0]:]

    dist = sess.run(pdist, feed_dict={matrix_a_placeholder: infer_data, matrix_b_placeholder: refer_data})
    error = knn(dist, k, refer_label, infer_label)
    mean = np.mean(error)
    std = np.std(error)
    print('Initial: \t\t mean: %1.3f \t std: %1.3f' % (float(mean), float(std)))

    dist = sess.run(pdist, feed_dict={matrix_a_placeholder: emb_infer, matrix_b_placeholder: emb_refer})
    error = knn(dist, k, refer_label, infer_label)
    mean = np.mean(error)
    std = np.std(error)
    print('Validation: \t mean: %1.3f \t std: %1.3f' % (float(mean), float(std)))

    # Add validation loss and accuracy to summary
    summary = tf.Summary()
    summary.value.add(tag='mean_error', simple_value=mean)
    summary.value.add(tag='std_error', simple_value=std)
    summary_writer.add_summary(summary, step)
    with open(os.path.join(log_dir, 'validation_result.txt'), 'at') as f:
        f.write('[%3.3d][%7.7d]\t%.5f\t%.5f\n' % (epoch, step, float(mean), float(std)))
    return mean


def knn(dist, k, refer_label, infer_label):
    location = []
    for i, one in enumerate(dist):
        arg = np.argsort(one, kind='mergesort')[:k]
        loc = np.mean(refer_label[arg, 1:], axis=0)
        location.append(loc)
    location = np.row_stack(location)
    error = np.sqrt(np.sum(np.square(infer_label[:, 1:] - location), axis=1))
    return error


def save_variables_and_metagraph(sess, saver, summary_writer, model_dir, model_name, step):
    # Save the model checkpoint
    print('Saving variables', end='')
    start_time = time.time()
    checkpoint_path = os.path.join(model_dir, 'model-%s.ckpt' % model_name)
    saver.save(sess, checkpoint_path, global_step=step, write_meta_graph=False)
    save_time_variables = time.time() - start_time
    print('in %.2f seconds' % save_time_variables)
    metagraph_filename = os.path.join(model_dir, 'model-%s.meta' % model_name)
    save_time_metagraph = 0
    if not os.path.exists(metagraph_filename):
        print('Saving metagraph')
        start_time = time.time()
        saver.export_meta_graph(metagraph_filename)
        save_time_metagraph = time.time() - start_time
        print('Metagraph saved in %.2f seconds' % save_time_metagraph)
    summary = tf.Summary()
    summary.value.add(tag='time/save_variables', simple_value=save_time_variables)
    summary.value.add(tag='time/save_metagraph', simple_value=save_time_metagraph)
    summary_writer.add_summary(summary, step)
    return checkpoint_path


def pdist(a, b):
    with tf.variable_scope('pairs_dist'):
        a_each_vector_a_mul_at = tf.reshape(tf.reduce_sum(tf.square(a), 1), [-1, 1])
        b_each_vector_b_mul_bt = tf.reshape(tf.reduce_sum(tf.square(b), 1), [1, -1])
        dist = tf.subtract(tf.add(a_each_vector_a_mul_at, b_each_vector_b_mul_bt), tf.multiply(tf.constant(2, dtype=tf.float32), tf.matmul(a, tf.transpose(b))))
    return dist