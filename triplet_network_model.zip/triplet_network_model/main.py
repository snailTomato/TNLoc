from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import tensorflow as tf
import numpy as np
import sys
from datetime import datetime
import os
import importlib
import funclib
import properties


def main(args):
    # Load fingerprint map
    train_data,train_label = funclib.load_train_data(args.dataPath)
    # Divide the data into 30% test data and 70% train data for the later validation
    refer_data, refer_label, infer_data, infer_label = funclib.sample_data(train_label, train_data, 0.7)
    # Save the log
    subdir = datetime.strftime(datetime.now(), '%Y%m%d-%H%M%S')
    log_dir = os.path.join(os.path.expanduser(args.logs_base_dir), subdir)
    if not os.path.isdir(log_dir):
        os.makedirs(log_dir)
    # Save the model
    model_dir = os.path.join(os.path.expanduser(args.models_base_dir), subdir)
    if not os.path.isdir(model_dir):
        os.makedirs(model_dir)
    with open(os.path.join(log_dir, 'parameters.txt'), 'at') as f:
        f.write('Alpha: %.2f \nEmbedding size: %d \nK: %d \nKeep prob: %.2f \nOptimizer: %s \nTriplet k: %d \n'
                % (args.alpha, args.embedding_size, args.k, args.keep_prob, args.optimizer, args.triplet_k))

    if args.pretrained_model:
        print('Pre-trained model: %s' % os.path.expanduser(args.pretrained_model))

    # Set model
    network = importlib.import_module(args.model_def)
    # Graph start
    with tf.Graph().as_default():
        tf.set_random_seed(args.seed)
        global_step = tf.Variable(0, name='global_step', trainable=False)

        # Placeholder
        learning_rate_placeholder = tf.placeholder(tf.float32, name='learning_rate')
        rss_placeholder = tf.placeholder(tf.float32, shape=(None, train_data.shape[1]), name='rss')
        sl_placeholder = tf.placeholder(tf.float32, shape=(None,), name='same_location')
        train_phase_placeholder = tf.placeholder(tf.bool, name='training_phase')

        inputs = tf.expand_dims(rss_placeholder, 2)


        represent, _ = network.cf_network(inputs, bottleneck_size=args.embedding_size,  weight_decay=args.weight_decay, is_training=train_phase_placeholder)

        embeddings = tf.nn.l2_normalize(represent, 1, 1e-10, name='embeddings')

        anchor, positive, negative = tf.unstack(tf.reshape(embeddings, [-1, 3, args.embedding_size]), 3, 1)
        triplet_loss = funclib.triplet_loss(anchor, positive, negative, args.alpha)


        # Learning rate decay
        learning_rate = tf.train.exponential_decay(learning_rate_placeholder, global_step, args.lr_decay_epochs * 10000, args.learning_rate_decay_factor, staircase=False)
        tf.summary.scalar('learning_rate', learning_rate)

        # Total loss
        regularization_losses = tf.get_collection(tf.GraphKeys.REGULARIZATION_LOSSES)
        total_loss = tf.add_n([triplet_loss] + regularization_losses, name='total_loss')

        # Build a Graph that trains the model with one batch of examples and updates the model parameters
        train_op = funclib.graph_train(total_loss, global_step, args.optimizer, learning_rate, args.moving_average_decay, tf.global_variables())

        # Create a saver
        saver = tf.train.Saver(tf.global_variables(), max_to_keep=3)

        # Start running operations on the Graph.
        sess = tf.Session(config=tf.ConfigProto(gpu_options=tf.GPUOptions(per_process_gpu_memory_fraction=args.gpu_memory_fraction)))
        # Initialize variables
        sess.run(tf.global_variables_initializer())

        summary_writer = tf.summary.FileWriter(log_dir, sess.graph)

        # Accelerate pdist
        matrix_a_placeholder = tf.placeholder(tf.float32, name='matrix_A')
        matrix_b_placeholder = tf.placeholder(tf.float32, name='matrix_B')
        pdist = tf.maximum(funclib.pdist(matrix_a_placeholder, matrix_b_placeholder), 0.0)

        # Train model
        with sess.as_default():

            same_location = np.equal(np.expand_dims(train_label[:, 0], axis=0), np.expand_dims(train_label[:, 0], axis=1))
            uLable,arg = np.unique(train_label, axis=0, return_inverse=True)
            real_dist = sess.run(pdist, feed_dict={matrix_a_placeholder: uLable, matrix_b_placeholder: uLable})
            upositive_points_candidate = np.argsort(real_dist, axis=1, kind='mergesort')
            if not np.all(np.equal(np.arange(upositive_points_candidate.shape[0]), upositive_points_candidate[:, 0])):
                raise ValueError('pdist error!')

            epoch = 0
            while epoch <= args.max_nrof_epochs:
                step = sess.run(global_step, feed_dict=None)
                # Train for one epoch
                funclib.train(args, sess, epoch, train_data, same_location, upositive_points_candidate, train_phase_placeholder,
                      rss_placeholder, sl_placeholder, learning_rate_placeholder, global_step, embeddings, total_loss,
                      train_op, summary_writer, args.embedding_size, matrix_a_placeholder, matrix_b_placeholder, pdist, learning_rate)
                # Validation
                funclib.evaluate(sess, rss_placeholder, embeddings, pdist, matrix_a_placeholder, matrix_b_placeholder, step, epoch, train_phase_placeholder,
                               refer_data, refer_label, infer_data, infer_label, log_dir, summary_writer, args.k, args.embedding_size, args.batch_size)
                # Save variables and the metagraph if it perform better
                funclib.save_variables_and_metagraph(sess, saver, summary_writer, model_dir, subdir, step) + '-' + str(step)
                epoch += 1
    return model_dir


if __name__ == '__main__':
    main(properties.parse_arguments(sys.argv[1:]))

