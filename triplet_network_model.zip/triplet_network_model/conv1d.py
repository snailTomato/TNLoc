import tensorflow as tf
from tensorflow.contrib import layers
from tensorflow.contrib.framework.python.ops import arg_scope
from tensorflow.contrib.layers.python.layers import layers
from tensorflow.contrib.layers.python.layers import regularizers
from tensorflow.contrib.layers.python.layers import utils
from tensorflow.python.ops import nn
from tensorflow.python.ops import variable_scope


def cf_network(inputs, bottleneck_size=1000, weight_decay=0.0005, is_training=True, scope='1c_1f'):
    """Network model.

    Convolutional network + fully connected network.

    Args:
      inputs: model name(conv1d) .
    Returns:
      net: the network
    """
    # Batch norm for avoiding overfitting
    batch_norm_params = {
        # Decay for the moving averages.
        'decay': 0.999,
        # epsilon to prevent 0s in variance.
        'epsilon': 0.001,
        # force in-place updates of mean and variance estimates
        'updates_collections': None,
        # Moving averages ends up in the trainable variables collection
        'variables_collections': [tf.GraphKeys.TRAINABLE_VARIABLES],
    }
    with variable_scope.variable_scope(scope, '1c_1f', [inputs]) as sc:
        end_points_collection = sc.original_name_scope + '_end_points'
        with arg_scope([layers.batch_norm, layers.dropout],
                       is_training=is_training):
            with arg_scope([layers.conv1d, layers.fully_connected],
                           weights_initializer=layers.initializers.xavier_initializer(),
                           weights_regularizer=regularizers.l2_regularizer(weight_decay),
                           normalizer_fn=layers.batch_norm, normalizer_params=batch_norm_params):
                net = layers.conv1d(inputs, 100, [2], stride=1, padding='VALID', activation_fn=nn.relu, scope='cv1')
                net = layers.flatten(net)
                net = layers.fully_connected(net, 256, scope='fc1')
                net = layers.fully_connected(net, bottleneck_size, normalizer_fn=None, activation_fn=None, scope='Bottleneck')

                end_points = utils.convert_collection_to_dict(end_points_collection)
                end_points[sc.name + '/Bottleneck'] = net
                return net, end_points
