import argparse


def parse_arguments(argv):
    parser = argparse.ArgumentParser()
    parser.add_argument('--k', type=int,
                        help='Value of k in kNN.',
                        default=3)
    parser.add_argument('--model', type=str,
                        help='Could be either a directory containing the meta_file and ckpt_file or a model protobuf (.pb) file',
                        default='./TNLocLib/models/20190118-193650')
    parser.add_argument('--emb_train_path', type=str,
                        help='Path of the embedding train data(.np)',
                        default='./TNLocLib/data/emb_train.npy')
    parser.add_argument('--train_label_path', type=str,
                        help='Path of the train data label(.np)',
                        default='./TNLocLib/data/train_label.npy')
    parser.add_argument('--sample_size', type=int,
                        help='wifi sample size',
                        default=15)
    parser.add_argument('--seed', type=int,
                        help='Random seed.', default=666)
    parser.add_argument('--gpu_memory_fraction', type=float,
                        help='Upper bound on the amount of GPU memory that will be used by the process.', default=1.0)
    return parser.parse_args(argv)