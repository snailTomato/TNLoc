import tensorflow as tf
from tensorflow.python.platform import gfile
import TNLocLib.properties
import numpy as np
import os
import re
import sys
_SAMPLE_SIZE = TNLocLib.properties.parse_arguments(sys.argv[1:]).sample_size


def get_localization_result(args, emb_train, train_label, rssi_a, rssi_b, rssi_c):
    """Get result

    Prepare the observation and use fun triplet_net_localizaiton() to get result.

       Args:
         rssi_a: rssi from wi_fi A.
       Returns:
         p_loc: target location(x,y).
         prob_list: probability in each Reference points <p1,p2,p3,p4,p5>.
    """
    observation = []
    observation.append(rssi_a)
    observation.append(rssi_b)
    observation.append(rssi_c)

    observation = [i+100 for i in observation]
    observation = np.expand_dims(observation[:], axis=0)
    prob_list, p_loc = triplet_net_localizaiton(args, emb_train, train_label, observation)
    return prob_list, p_loc


def triplet_net_localizaiton(args, emb_train, train_label, observation):
    """Use triplet net model to localization.

    Args:
      observation: RSSI list<a,b,c>
    Returns:
        p_loc: target location(x,y).
        prob_list: probability in each Reference points <p1,p2,p3,p4,p5>.
    """
    with tf.Graph().as_default():
        with tf.Session() as sess:
            # Load the model
            load_model(args.model)
            # Get input and output tensors
            rss_placeholder = tf.get_default_graph().get_tensor_by_name("rss:0")
            embeddings = tf.get_default_graph().get_tensor_by_name("embeddings:0")
            phase_train_placeholder = tf.get_default_graph().get_tensor_by_name("training_phase:0")

            # Accelerate pdist
            matrix_a_placeholder = tf.placeholder(tf.float32, name='matrix_A')
            matrix_b_placeholder = tf.placeholder(tf.float32, name='matrix_B')
            pdist = tf.maximum(m_pdist(matrix_a_placeholder, matrix_b_placeholder), 0.0)
            k_placeholder = tf.placeholder(tf.int32)
            _, topk = tf.nn.top_k(tf.negative(pdist), k_placeholder)

            emb_test = sess.run(embeddings, feed_dict={rss_placeholder: observation, phase_train_placeholder: False})
            nearest = sess.run(topk, feed_dict={matrix_a_placeholder: emb_test, matrix_b_placeholder: emb_train, \
                                                k_placeholder: args.k})
            emb_emission_dist = sess.run(pdist, feed_dict={matrix_a_placeholder: emb_test, \
                                                           matrix_b_placeholder: emb_train})
            u_emb_emission_dist = []
            for i in range(0, 5):
                u_sum = [np.sum(emb_emission_dist[0, n]) for n in range(i*_SAMPLE_SIZE, (i+1)*_SAMPLE_SIZE)]
                u_emb_emission_dist.append(np.sum(u_sum))

            ant_emission_dist = [1 / np.square(one) for one in u_emb_emission_dist]
            label_proba = ant_emission_dist / np.sum(ant_emission_dist)
            p_loc = np.mean([train_label[one, :] for one in nearest[0]], axis=0)
            return label_proba, p_loc


def load_model(model):
    """Load trained model.

        Args:
          model: path
    """
    # Check if the model is a model directory (containing a metagraph and a checkpoint file)
    #  or if it is a protobuf file with a frozen graph
    model_exp = os.path.expanduser(model)
    if (os.path.isfile(model_exp)):
        print('Model filename: %s' % model_exp)
        with gfile.FastGFile(model_exp, 'rb') as f:
            graph_def = tf.GraphDef()
            graph_def.ParseFromString(f.read())
            tf.import_graph_def(graph_def, name='')
    else:
        print('Model directory: %s' % model_exp)
        meta_file, ckpt_file = get_model_filenames(model_exp)

        print('Metagraph file: %s' % meta_file)
        print('Checkpoint file: %s' % ckpt_file)

        saver = tf.train.import_meta_graph(os.path.join(model_exp, meta_file))
        saver.restore(tf.get_default_session(), os.path.join(model_exp, ckpt_file))


def load_train_data(args):
    """Load embadding fingerprint map.

    Args:
      file_name: str
    Returns:
      train_rssi: rssi matrix[RP,AP] for fingerprint map.
      train_label: lable matrix[RP,2] for fingerprint map, lable is laction (x,y).
    """
    emb_train = np.load(args.emb_train_path)
    train_label = np.load(args.train_label_path)
    return emb_train, train_label


def get_model_filenames(model_dir):
    files = os.listdir(model_dir)
    meta_files = [s for s in files if s.endswith('.meta')]
    if len(meta_files) == 0:
        raise ValueError('No meta file found in the model directory (%s)' % model_dir)
    elif len(meta_files) > 1:
        raise ValueError('There should not be more than one meta file in the model directory (%s)' % model_dir)
    meta_file = meta_files[0]
    meta_files = [s for s in files if '.ckpt' in s]
    max_step = -1
    for f in files:
        step_str = re.match(r'(^model-[\w\- ]+.ckpt-(\d+))', f)
        if step_str is not None and len(step_str.groups()) >= 2:
            step = int(step_str.groups()[1])
            if step > max_step:
                max_step = step
                ckpt_file = step_str.groups()[0]
    return meta_file, ckpt_file


def knn(dist, k, tls, label_t, label_v=None):
    true_labels = label_v if label_v is not None else label_t
    error = []
    floor = []
    location = []
    for i, one in enumerate(dist):
        arg = np.argsort(one, kind='mergesort')[:k]
        floor.append(tls[arg[0]])
        loc = np.mean(label_t[arg, :2], 0)
        location.append(loc)
        real_loc = true_labels[i, :2]
        error.append(np.sqrt(np.sum(np.square(real_loc - loc))))
    floor = np.array(floor)
    error = np.array(error)
    return floor, error


def m_pdist(a, b):
    with tf.variable_scope('pairs_dist'):
        a_each_vector_a_mul_at = tf.reshape(tf.reduce_sum(tf.square(a), 1), [-1, 1])
        b_each_vector_b_mul_bt = tf.reshape(tf.reduce_sum(tf.square(b), 1), [1, -1])
        dist = tf.subtract(tf.add(a_each_vector_a_mul_at, b_each_vector_b_mul_bt), \
                           tf.multiply(tf.constant(2, dtype=tf.float32), tf.matmul(a, tf.transpose(b))))
    return dist

