import TNLocLib.funclib
import TNLocLib.properties
import sys


if __name__ == '__main__':

    args = TNLocLib.properties.parse_arguments(sys.argv[1:])
    # Initial
    emb_train, train_label = TNLocLib.funclib.load_train_data(args)
    # input value -77, -76, -72 from web
    # return list<p1,p2,p3> and location(x,y), show in web
    print(TNLocLib.funclib.get_localization_result(args, emb_train, train_label, -77, -76, -72))


