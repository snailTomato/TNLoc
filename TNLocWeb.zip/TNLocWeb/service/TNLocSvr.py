from utils import log
from utils.singleton import Singleton
from TNLocLib import funclib, properties
import sys


class TNLocSvr():

    __metaclass__ = Singleton

    def __init__(self):
        self.args = properties.parse_arguments(sys.argv[1:])
        self.emb_train, self.train_label = funclib.load_train_data(self.args)
        self.logger = log.get_logger(self.__class__.__name__)

    def get_localization_result(self, WiFi_A, WiFi_B, WiFi_C):
        self.logger.info("request args:%s %s %s"%(WiFi_A, WiFi_B, WiFi_C))

        try:
            res = funclib.get_localization_result(self.args, self.emb_train, self.train_label, WiFi_A, WiFi_B, WiFi_C)
        except () as e:
            res = str(e)
            return 0, res

        input_list = [WiFi_A, WiFi_B, WiFi_C]
        prob_list = res[0]
        xy = res[1]
        x, y = xy.tolist()

        SIZE = 100000000

        # Result in text box
        resStr = "In put: " + ", ".join([str('%.2f' % one) for one in input_list]) + "\nOut put: list<p1,p2,p3,p4,p5> is:" + \
                 ", ".join([str('%.2f' % one) for one in prob_list]) + "\nlocation<x,y>:" + ", ".join([str(one) for one in xy])

        # Prepare probability data for 4 circle and location circle
        option = [
            [
                [4, 0, int(SIZE * prob_list[0] * 100), "Location 1:\n %.2f%%" % (prob_list[0] * 100)],
                [4, 1, int(SIZE * prob_list[1] * 100), "Location 2:\n %.2f%%" % (prob_list[1] * 100)],
                [3, 1, int(SIZE * prob_list[2] * 100), "Location 3:\n %.2f%%" % (prob_list[2] * 100)],
                [2, 1, int(SIZE * prob_list[3] * 100), "Location 4:\n %.2f%%" % (prob_list[3] * 100)],
                [0, 1, int(SIZE * prob_list[4] * 100), "Location 5:\n %.2f%%" % (prob_list[4] * 100)],
            ],
            [
                # location and size
                [x, y, SIZE, '']
            ],

        ]

        res = {"resStr": resStr, "option": option}

        return 1, res
