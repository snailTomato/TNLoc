from flask import Flask, render_template, request, jsonify
from service import TNLocSvr
import math
app = Flask(__name__)
TNLOCSVR = TNLocSvr.TNLocSvr()


def SUCC(res):
    return jsonify({'status': 'succ', 'res': res})


def ERROR(msg):
    return jsonify({'status': 'error', 'res': msg})


@app.route('/')
def index():
    return render_template("index.html")


def reform_input(s):
    try:
        s = float(s)
        if 100 > abs(s) > 0:
            return -abs(s)
        else:
            return -100
    except ValueError:
        pass
    return -100


@app.route('/tnloc', methods=['POST'])
def tnloc():
    WiFi_A = request.form.get("WiFi_A", "default")
    WiFi_B = request.form.get("WiFi_B", "default")
    WiFi_C = request.form.get("WiFi_C", "default")

    stat, res = TNLOCSVR.get_localization_result(reform_input(WiFi_A), reform_input(WiFi_B), reform_input(WiFi_C))
    if stat:
        return SUCC(res)
    else:
        return ERROR(res)


if __name__ == '__main__':
    app.run("0.0.0.0")
    # app.run()
