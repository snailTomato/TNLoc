import logging
import os
import sys


def get_logger(name):
    log_dir = "logs"
    log_path = os.path.join(log_dir, name+".log")
    if not os.path.isdir(log_dir):
        os.makedirs(log_dir)
    logger = logging.getLogger(name)
    logger.setLevel(logging.DEBUG)

    loghandler = logging.FileHandler(log_path)
    loghandler.setLevel(logging.DEBUG)
    formatter = logging.Formatter("[%(asctime)s] - %(levelname)s :[%(name)s]%(message)s")
    loghandler.setFormatter(formatter)
    logger.addHandler(loghandler)

    ch = logging.StreamHandler(sys.stdout)
    ch.setLevel(logging.DEBUG)
    ch.setFormatter(formatter)
    logger.addHandler(ch)
    
    return logger
